#!/usr/bin/env python
"""Wrapper for extracting matisse.main() function."""
from .matisse import main
if __name__ == '__main__':
  main()
