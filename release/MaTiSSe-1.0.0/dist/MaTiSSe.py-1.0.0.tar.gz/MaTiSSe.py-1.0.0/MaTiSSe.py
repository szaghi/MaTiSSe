#!/usr/bin/env python
"""Wrapper of MaTiSSe.py program extracted from matisse package"""
from matisse.matisse import main
if __name__ == '__main__':
  main()
