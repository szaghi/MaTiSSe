"""Package defining the MaTiSSe.py program."""
