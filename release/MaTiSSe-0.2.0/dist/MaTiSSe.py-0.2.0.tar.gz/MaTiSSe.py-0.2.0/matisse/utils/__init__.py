"""
Module defining useful utilities for MaTiSSe.py.
"""

