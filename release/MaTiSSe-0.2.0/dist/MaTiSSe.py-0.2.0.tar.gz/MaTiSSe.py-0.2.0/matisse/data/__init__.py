"""
Module defining the presentation class of MaTiSSe.py.
"""
