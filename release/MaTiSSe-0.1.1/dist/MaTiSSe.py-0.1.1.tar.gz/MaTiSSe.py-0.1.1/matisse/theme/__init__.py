"""
Module defining the presentation Theme of a MaTiSSe.py presentation.
"""
